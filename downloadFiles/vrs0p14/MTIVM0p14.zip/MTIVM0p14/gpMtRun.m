function models = gpMtRun(X, y, kernelType, noiseType, optimiseNoise, display, iters)


% GPMTRUN Run a multi-task GP.
%
% models = gpMtRun(X, y, kernelType, noiseType, optimiseNoise, display, iters)
%

% Copyright (c) 2005 Neil D. Lawrence
% gpMtRun.m version 1.4


models = mtivm(X, y, kernelType, noiseType, 'none');

for i = 1:length(models)
  models.task(i) = ivmInit(models.task(i));
end
models = mtivmOptimiseKernel(models, display, iters);
if optimiseNoise
  models = mtivmOptimiseNoise(models, display, iters);
end
