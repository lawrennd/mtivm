% ICMLCLASSIFICATION Run the vowel demos for icml paper.
%
% 

% Copyright (c) 2005 Neil D. Lawrence
% icmlClassification.m version 1.3



icmlMtVowelDemo
icmlVowelDemo
icmlSampVowelDemo
icmlClassificationResults