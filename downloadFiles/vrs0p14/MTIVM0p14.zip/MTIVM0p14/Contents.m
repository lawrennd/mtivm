% MTIVM toolbox
% Version 0.14		Sunday 20 Nov 2005 at 20:59
% Copyright (c) 2005 Neil D. Lawrence
% 
% GENERATEMTREGRESSIONDATA Tries to load a muti-task regression sampled data set otherwise generates it.
% GENERATEVOWELDATA Produces vowel data in matlab format.
% GPMTRUN Run a multi-task GP.
% ICMLCLASSIFICATION Run the vowel demos for icml paper.
% ICMLCLASSIFICATIONRESULTS Plot the classificaiton results for ICML paper.
% ICMLMTREGRESSION Time the multi-task IVM and simple sub-sampling.
% ICMLMTREGRESSIONRESULTS Prepare comparision plots of the IVM vs sub-sampling.
% ICMLMTVOWELDEMO Recreate ICML experiment of multi-task IVM for classification of vowels.
% ICMLREGRESSIONRESULTS Prepare comparision plots of the IVM vs sub-sampling.
% ICMLSAMPVOWELDEMO Try sub sampling for the point sets for classification of vowels.
% ICMLTOYSINE A small demo for icml paper of the multi-task IVM.
% ICMLVOWELDEMO Try the IVM for classification of vowels.
% MTIVM Initialise an multi-task ivm model.
% MTIVMDISPLAY Display the mtivm model.
% MTIVMKERNELGRADIENT Gradient on likelihood approximation for multi-task IVM.
% MTIVMKERNELOBJECTIVE Likelihood approximation for multi-task IVM.
% MTIVMOPTIMISE Optimise the multi-task IVM.
% MTIVMOPTIMISEIVM Does point selection for a point-set IVM model.
% MTIVMOPTIMISEKERNEL Optimise the kernel parameters.
% MTIVMOPTIMISENOISE Optimise the noise parameters.
% MTIVMRUN Run multi-task IVM on a data-set.
