function mtivmDisplay(models);

% MTIVMDISPLAY Display the mtivm model.
%
% mtivmDisplay(models);
%

% Copyright (c) 2005 Neil D. Lawrence
% mtivmDisplay.m version 1.1



for taskNo = 1:models.numTasks
  ivmDisplay(models.task(taskNo));
end