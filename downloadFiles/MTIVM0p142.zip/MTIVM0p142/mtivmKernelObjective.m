function f = mtivmKernelObjective(params, models)

% MTIVMKERNELOBJECTIVE Likelihood approximation for multi-task IVM.
%
%	Description:
%	f = mtivmKernelObjective(params, models)
%% 	mtivmKernelObjective.m CVS version 1.2
% 	mtivmKernelObjective.m SVN version 473
% 	last update 2007-11-03T14:25:00.000000Z

if nargin < 3
  prior = 1;
end
f = 0;
numTasks = length(models.task);
for taskNo = 1:numTasks
  if(length(models.task(taskNo).I)>0)
    f = f + ivmKernelObjective(params, models.task(taskNo));
  end
end