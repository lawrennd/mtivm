function g = mtivmKernelGradient(params, models)

% MTIVMKERNELGRADIENT Gradient on likelihood approximation for multi-task IVM.
%
%	Description:
%	g = mtivmKernelGradient(params, models)
%% 	mtivmKernelGradient.m CVS version 1.2
% 	mtivmKernelGradient.m SVN version 473
% 	last update 2007-11-03T14:25:19.000000Z

if nargin < 3
  prior = 1;
end

g = zeros(size(params));
for taskNo = 1:models.numTasks
  if(length(models.task(taskNo).I)>0) % It's possible that this task wasn't used.
    g = g + ivmKernelGradient(params, models.task(taskNo));
  end
end
  
