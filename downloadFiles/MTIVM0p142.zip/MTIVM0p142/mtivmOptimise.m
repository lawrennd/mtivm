function models = mtivmOptimise(models, optimiseNoise, display, innerIters, ...
			     outerIters);

% MTIVMOPTIMISE Optimise the multi-task IVM.
%
%	Description:
%	models = mtivmOptimise(models, optimiseNoise, display, innerIters, ...
%			     outerIters);
%% 	mtivmOptimise.m CVS version 1.2
% 	mtivmOptimise.m SVN version 473
% 	last update 2007-11-03T14:25:00.000000Z

% Run IVM
for i = 1:outerIters
  models = mtivmOptimiseIVM(models, display);
  models = mtivmOptimiseKernel(models, display, innerIters);
  if optimiseNoise
    models = mtivmOptimiseIVM(models, display);
    models = mtivmOptimiseNoise(models, display, innerIters);
  end
  mtivmDisplay(models);
end
