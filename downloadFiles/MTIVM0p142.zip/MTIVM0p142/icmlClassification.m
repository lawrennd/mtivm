
% ICMLCLASSIFICATION Run the vowel demos for icml paper.
%
%	Description:
%	% 	icmlClassification.m CVS version 1.3
% 	icmlClassification.m SVN version 473
% 	last update 2007-11-03T14:25:20.000000Z

icmlMtVowelDemo
icmlVowelDemo
icmlSampVowelDemo
icmlClassificationResults