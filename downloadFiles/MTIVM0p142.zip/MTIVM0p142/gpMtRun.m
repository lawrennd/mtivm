function models = gpMtRun(X, y, kernelType, noiseType, optimiseNoise, display, iters)

% GPMTRUN Run a multi-task GP.
%
%	Description:
%	models = gpMtRun(X, y, kernelType, noiseType, optimiseNoise, display, iters)
%% 	gpMtRun.m CVS version 1.4
% 	gpMtRun.m SVN version 473
% 	last update 2007-11-03T14:25:04.000000Z
models = mtivm(X, y, kernelType, noiseType, 'none');

for i = 1:length(models)
  models.task(i) = ivmInit(models.task(i));
end
models = mtivmOptimiseKernel(models, display, iters);
if optimiseNoise
  models = mtivmOptimiseNoise(models, display, iters);
end
