function models = mtivmOptimiseNoise(models, display, iters);

% MTIVMOPTIMISENOISE Optimise the noise parameters.
%
%	Description:
%	models = mtivmOptimiseNoise(models, display, iters);
%% 	mtivmOptimiseNoise.m CVS version 1.2
% 	mtivmOptimiseNoise.m SVN version 473
% 	last update 2007-11-03T14:25:19.000000Z

if nargin < 3
  iters = 500;
  if nargin < 2
    display = 1;
  end
end
options = foptions;
if display
  options(1) = 1;
end
options(14) = iters;

for taskNo = 1:models.numTasks
  models.task(taskNo) = optimiseParams('noise', 'scg', ...
                                       'ivmNegLogLikelihood', ...
                                       'ivmNegGradientNoise', ...
                                       options, ...
                                       models.task(taskNo));
end