% MTIVM toolbox
% Version 0.142		12-Aug-2009
% Copyright (c) 2009, Neil D. Lawrence
% 
, Neil D. Lawrence
% MTIVM Initialise an multi-task ivm model.
% MTIVMDISPLAY Display the mtivm model.
% MTIVMOPTIMISE Optimise the multi-task IVM.
% GENERATEMTREGRESSIONDATA Tries to load a muti-task regression sampled data set otherwise generates it.
% MTIVMTOOLBOXES Toolboxes required for the MT-IVM demos.
% MTIVMKERNELOBJECTIVE Likelihood approximation for multi-task IVM.
% ICMLMTREGRESSION Time the multi-task IVM and simple sub-sampling.
% ICMLCLASSIFICATIONRESULTS Plot the classificaiton results for ICML paper.
% ICMLVOWELDEMO Try the IVM for classification of vowels.
% MTIVMRUN Run multi-task IVM on a data-set.
% GENERATEVOWELDATA Produces vowel data in matlab format.
% ICMLMTREGRESSIONRESULTS Prepare comparision plots of the IVM vs sub-sampling.
% ICMLREGRESSIONRESULTS Prepare comparision plots of the IVM vs sub-sampling.
% MTIVMKERNELGRADIENT Gradient on likelihood approximation for multi-task IVM.
% ICMLSAMPVOWELDEMO Try sub sampling for the point sets for classification of vowels.
% ICMLCLASSIFICATION Run the vowel demos for icml paper.
% MTIVMOPTIMISENOISE Optimise the noise parameters.
% GPMTRUN Run a multi-task GP.
% ICMLMTVOWELDEMO Recreate ICML experiment of multi-task IVM for classification of vowels.
% MTIVMOPTIMISEKERNEL Optimise the kernel parameters.
% MTIVMOPTIMISEIVM Does point selection for a point-set IVM model.
