function mtivmDisplay(models);

% MTIVMDISPLAY Display the mtivm model.
%
%	Description:
%	mtivmDisplay(models);
%% 	mtivmDisplay.m CVS version 1.1
% 	mtivmDisplay.m SVN version 473
% 	last update 2007-11-03T14:25:01.000000Z

for taskNo = 1:models.numTasks
  ivmDisplay(models.task(taskNo));
end