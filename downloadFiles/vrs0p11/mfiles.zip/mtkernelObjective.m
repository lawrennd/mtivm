function f = mtkernelObjective(params, models, prior)

% MTKERNELOBJECTIVE Likelihood approximation for multi-task IVM.
%
% f = mtkernelObjective(params, models, prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Thu Apr  1 01:56:27 2004
% MTIVM toolbox version 0.11



if nargin < 3
  prior = 1;
end
f = 0;
numTasks = length(models.task);
for taskNo = 1:numTasks
  f = f + kernelObjective(params, models.task(taskNo), prior);
end