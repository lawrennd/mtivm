function g = mtkernelGradient(params, models, prior)

% MTKERNELGRADIENT Gradient on likelihood approximation for multi-task IVM.
%
% g = mtkernelGradient(params, models, prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Thu Apr  1 01:56:27 2004
% MTIVM toolbox version 0.11



if nargin < 3
  prior = 1;
end

g = zeros(size(params));
for taskNo = 1:models.numTasks
  g = g + kernelGradient(params, models.task(taskNo), prior);
end
  
