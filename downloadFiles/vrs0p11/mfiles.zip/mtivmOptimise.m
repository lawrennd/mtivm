function models = mtivmOptimise(models, prior, display, innerIters, ...
			     outerIters);

% MTIVMOPTIMISE Optimise the multi-task IVM.
%
% models = mtivmOptimise(models, prior, display, innerIters, ...
% 			     outerIters);

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Mon Apr  5 00:11:56 2004
% MTIVM toolbox version 0.11



% Run IVM
for i = 1:outerIters
  models = mtivmOptimiseIVM(models, display);
  models = mtivmOptimiseNoise(models, prior, display, innerIters);
  models = mtivmOptimiseKernel(models, prior, display, innerIters);
end
