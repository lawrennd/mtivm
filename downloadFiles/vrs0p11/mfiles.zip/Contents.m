% MTIVM toolbox
% Version 0.11 Thursday, April 22, 2004 at 04:14:59
% Copyright (c) 2004 Neil D. Lawrence
% $Revision: 1.1 1.0 $
% 
% ICMLMTVOWELDEMO Recreate ICML experiment of multi-task IVM for classification of vowels.
% ICMLTOYSINE A small demo for icml paper of the multi-task IVM.
% MTIVM Initialise an multi-task ivm model.
% MTIVMOPTIMISE Optimise the multi-task IVM.
% MTIVMOPTIMISEIVM Does point selection for a point-set IVM model.
% MTIVMOPTIMISENOISE Optimise the noise parameters.
% MTIVMRUN Run multi-task IVM on a data-set.
% MTKERNELGRADIENT Gradient on likelihood approximation for multi-task IVM.
% MTKERNELOBJECTIVE Likelihood approximation for multi-task IVM.
