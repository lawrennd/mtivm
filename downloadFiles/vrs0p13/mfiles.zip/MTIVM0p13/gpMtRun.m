function models = gpMtRun(X, y, kernelType, noiseType, optimiseNoise, display, iters)


% GPMTRUN Run a multi-task GP.
%
% models = gpMtRun(X, y, kernelType, noiseType, optimiseNoise, display, iters)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.4, Thu Jun 24 08:32:19 2004
% MTIVM toolbox version 0.13


models = mtivm(X, y, kernelType, noiseType, 'none');

for i = 1:length(models)
  models.task(i) = ivmInit(models.task(i));
end
models = mtivmOptimiseKernel(models, display, iters);
if optimiseNoise
  models = mtivmOptimiseNoise(models, display, iters);
end
