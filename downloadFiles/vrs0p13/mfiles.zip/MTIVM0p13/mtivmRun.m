function models = mtivmRun(XTrain, yTrain, kernelType, noiseType, ...
                           selectionCriterion, dVal, optimiseNoise, display, ...
                           innerIters, outerIters, ...
                           noiseTieStructure, kernelTieStructure)

% MTIVMRUN Run multi-task IVM on a data-set.
%
% models = mtivmRun(XTrain, yTrain, kernelType, noiseType, ...
%                            selectionCriterion, dVal, optimiseNoise, display, ...
%                            innerIters, outerIters, ...
%                            noiseTieStructure, kernelTieStructure)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Fri Jun 18 14:28:21 2004
% MTIVM toolbox version 0.13



% Intitalise MT-IVM
models = mtivm(XTrain, yTrain, kernelType, noiseType, selectionCriterion, dVal);
if nargin > 11 & ~isempty(noiseTieStructure)
  % Some of the noise parameters are constrained equal to each other
  for taskNo = 1:models.numTasks
    models.task(taskNo).noise = cmpndTieParameters(models.task(taskNo).noise, ...
                                                  noiseTieStructure);
  end
end

if nargin > 10 & ~isempty(kernelTieStructure)
  % Some of the kernel parameters are constrained to equal each other.
  for taskNo = 1:models.numTasks
    models.task(taskNo).kern = cmpndTieParameters(models.task(taskNo).kern, ...
                                                  kernelTieStructure);
  end
end

% Optimise MT-IVM
models = mtivmOptimise(models, optimiseNoise, display, innerIters, outerIters);