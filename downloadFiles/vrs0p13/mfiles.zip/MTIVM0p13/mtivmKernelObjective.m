function f = mtivmKernelObjective(params, models)

% MTIVMKERNELOBJECTIVE Likelihood approximation for multi-task IVM.
%
% f = mtivmKernelObjective(params, models)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Wed Jun 23 08:23:10 2004
% MTIVM toolbox version 0.13



if nargin < 3
  prior = 1;
end
f = 0;
numTasks = length(models.task);
for taskNo = 1:numTasks
  f = f + ivmKernelObjective(params, models.task(taskNo));
end