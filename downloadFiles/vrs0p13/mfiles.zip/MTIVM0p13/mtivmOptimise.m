function models = mtivmOptimise(models, optimiseNoise, display, innerIters, ...
			     outerIters);

% MTIVMOPTIMISE Optimise the multi-task IVM.
%
% models = mtivmOptimise(models, optimiseNoise, display, innerIters, ...
% 			     outerIters);

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Fri Jun 18 14:38:02 2004
% MTIVM toolbox version 0.13



% Run IVM
for i = 1:outerIters
  models = mtivmOptimiseIVM(models, display);
  models = mtivmOptimiseKernel(models, display, innerIters);
  if optimiseNoise
    models = mtivmOptimiseIVM(models, display);
    models = mtivmOptimiseNoise(models, display, innerIters);
  end
  mtivmDisplay(models);
end
