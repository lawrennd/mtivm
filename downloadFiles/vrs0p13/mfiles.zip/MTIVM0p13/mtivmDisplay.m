function mtivmDisplay(models);

% MTIVMDISPLAY Display the mtivm model.
%
% mtivmDisplay(models);

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Fri Jun 18 14:17:47 2004
% MTIVM toolbox version 0.13



for taskNo = 1:models.numTasks
  ivmDisplay(models.task(taskNo));
end