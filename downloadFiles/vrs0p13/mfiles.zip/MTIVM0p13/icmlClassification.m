% ICMLCLASSIFICATION Run the vowel demos for icml paper.
%
%
% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Wed Jun 23 07:01:08 2004
% MTIVM toolbox version 0.13



icmlMtVowelDemo
icmlVowelDemo
icmlSampVowelDemo
icmlClassificationResults