function g = mtivmKernelGradient(params, models)

% MTIVMKERNELGRADIENT Gradient on likelihood approximation for multi-task IVM.
%
% g = mtivmKernelGradient(params, models)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Wed Jun 23 08:23:33 2004
% MTIVM toolbox version 0.13



if nargin < 3
  prior = 1;
end

g = zeros(size(params));
for taskNo = 1:models.numTasks
  g = g + ivmKernelGradient(params, models.task(taskNo));
end
  
