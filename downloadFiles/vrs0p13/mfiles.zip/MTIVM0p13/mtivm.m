function models = mtivm(X, y, kernelType, noiseType, selectionCriterion, d)

% MTIVM Initialise an multi-task ivm model.
%
% models = mtivm(X, y, kernelType, noiseType, selectionCriterion, d)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Thu Apr  1 01:56:27 2004
% MTIVM toolbox version 0.13



if nargin < 6
  d = [];
end
models.kernelType = kernelType;
models.noiseType = noiseType;
models.selectionCriterion = selectionCriterion;

models.numTasks = length(X);
for taskNo = 1:models.numTasks
  models.task(taskNo) = ...
      ivm(X{taskNo}, y{taskNo}, kernelType, ...
	  noiseType, selectionCriterion, d);
end
models.d = d;
% Remove fields from the sub-structures.
for taskNo = 1:models.numTasks
  rmfield(models.task, 'd');
end
